package cn.blatter.network.service.impl;

import cn.blatter.network.domain.*;
import cn.blatter.network.mapper.NodeMapper;
import cn.blatter.network.mapper.PipeMapper;
import cn.blatter.network.service.NodeService;
import cn.blatter.network.utils.XMLUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service("nodeService")
public class NodeServiceImpl implements NodeService {

	@Autowired
	private NodeMapper nodeMapper;

	@Autowired
	private ElementServiceImpl elementService;

	@Autowired
	private ConnectionServiceImpl connectionService;

	@Autowired
	private ProjectsServiceImpl projectsService;

	@Autowired
	private PipeMapper pipeMapper;

	//private static String path1 = "src/main/resources";

	private String path1 = getPathRoot();

	public String getPathRoot() {
		String pathRoot = this.getClass().getResource("").getPath();
		//System.out.println(pathRoot);
		int index = pathRoot.indexOf("target/");
		if(pathRoot.charAt(0)=='f' && isWindows()) {
			pathRoot = pathRoot.substring(6, index);
		}
		else if(pathRoot.charAt(0)=='f' && isLinux()){
			pathRoot = pathRoot.substring(5, index);
		}
		else{
			pathRoot = pathRoot.substring(1, index);
		}
		pathRoot = pathRoot + "target/classes/";
		//System.out.println(pathRoot);
		return pathRoot;
	}

	public static boolean isLinux() {
		return System.getProperty("os.name").toLowerCase().contains("linux");
	}

	public static boolean isWindows() {
		return System.getProperty("os.name").toLowerCase().contains("windows");
	}

	@Override
	public List<Node> findAll(Integer id) {
		List<Node> nodeList = nodeMapper.findAll(id);
		return nodeList;
	}

	@Override
	public void deleteNode(Integer id){
		try {
			Node node = findById(id);
			String path = path1 + projectsService.queryOne(node.getProjectId()).getModel();
			List<Element> elements = elementService.findAll();
			List<Connection> connections = connectionService.findAll();
			XMLUtil xmlUtil = new XMLUtil(elements, connections);
			List<Pipe> pipeList = xmlUtil.deleteNode(path, node);
			for (Pipe pipe : pipeList) {
				Pipe temp = pipeMapper.queryByModelId(pipe);
				pipeMapper.deleteById(temp.getId());
			}
			nodeMapper.deleteNode(id);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void addNode(Node node){
		try {
			String path = path1 + projectsService.queryOne(node.getProjectId()).getModel();
			List<Element> elements = elementService.findAll();
			List<Connection> connections = connectionService.findAll();
			XMLUtil xmlUtil = new XMLUtil(elements, connections);
			xmlUtil.insertNode(path, node);
			nodeMapper.addBase(node);
			nodeMapper.addNode(node);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setNode(Node node){
		try {
			String path = path1 + projectsService.queryOne(node.getProjectId()).getModel();
			List<Element> elements = elementService.findAll();
			List<Connection> connections = connectionService.findAll();
			XMLUtil xmlUtil = new XMLUtil(elements, connections);
			xmlUtil.updateNode(path, node);
			nodeMapper.setBase(node);
			nodeMapper.setNode(node);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Node findById(Integer id){
		Node nodeList = nodeMapper.getBaseById(id);
		return nodeList;
	}

	@Override
	public List<Base> findAllBase(Integer id) {
		List<Base> list = nodeMapper.findAllBase(id);
		return list;
	}

}
