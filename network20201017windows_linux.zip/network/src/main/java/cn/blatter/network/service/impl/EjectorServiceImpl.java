package cn.blatter.network.service.impl;

import cn.blatter.network.domain.*;
import cn.blatter.network.mapper.EjectorMapper;
import cn.blatter.network.mapper.PipeMapper;
import cn.blatter.network.service.EjectorService;
import cn.blatter.network.utils.XMLUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service("ejectorService")
public class EjectorServiceImpl implements EjectorService {

    @Autowired
    private EjectorMapper ejectorMapper;

    @Autowired
    private ElementServiceImpl elementService;

    @Autowired
    private ConnectionServiceImpl connectionService;

    @Autowired
    private ProjectsServiceImpl projectsService;

    @Autowired
    private PipeMapper pipeMapper;

    private String path1 = getPathRoot();

    public String getPathRoot() {
        String pathRoot = this.getClass().getResource("").getPath();
        //System.out.println(pathRoot);
        int index = pathRoot.indexOf("target/");
        if(pathRoot.charAt(0)=='f' && isWindows()) {
            pathRoot = pathRoot.substring(6, index);
        }
        else if(pathRoot.charAt(0)=='f' && isLinux()){
            pathRoot = pathRoot.substring(5, index);
        }
        else{
            pathRoot = pathRoot.substring(1, index);
        }
        pathRoot = pathRoot + "target/classes/";
        //System.out.println(pathRoot);
        return pathRoot;
    }

    public static boolean isLinux() {
        return System.getProperty("os.name").toLowerCase().contains("linux");
    }

    public static boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().contains("windows");
    }

    @Override
    public List<Ejector> findAll(Integer id) {
        List<Ejector> ejectorList = ejectorMapper.findAll(id);
        return ejectorList;
    }

    @Override
    public void deleteEjector(Integer id){
        try {
            Ejector ejector = findById(id);
            String path = path1 + projectsService.queryOne(ejector.getProjectId()).getModel();
            List<Element> elements = elementService.findAll();
            List<Connection> connections = connectionService.findAll();
            XMLUtil xmlUtil = new XMLUtil(elements, connections);
            List<Pipe> pipeList = xmlUtil.deleteNode(path, ejector);
            for (Pipe pipe : pipeList) {
                Pipe temp = pipeMapper.queryByModelId(pipe);
                pipeMapper.deleteById(temp.getId());
            }
            ejectorMapper.deleteEjector(id);
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void addEjector(Ejector ejector){
        try {
            String path = path1 + projectsService.queryOne(ejector.getProjectId()).getModel();
            List<Element> elements = elementService.findAll();
            List<Connection> connections = connectionService.findAll();
            XMLUtil xmlUtil = new XMLUtil(elements, connections);
            xmlUtil.insertNode(path, ejector);
            ejectorMapper.addBase(ejector);
            ejectorMapper.addEjector(ejector);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("添加节点失败");
        }
    }

    @Override
    public void setEjector(Ejector ejector){
        try {
            String path = path1 + projectsService.queryOne(ejector.getProjectId()).getModel();
            List<Element> elements = elementService.findAll();
            List<Connection> connections = connectionService.findAll();
            XMLUtil xmlUtil = new XMLUtil(elements, connections);
            xmlUtil.updateNode(path, ejector);
            ejectorMapper.setBase(ejector);
            ejectorMapper.setEjector(ejector);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Ejector findById(Integer id){
        Ejector ejectorList = ejectorMapper.getBaseById(id);
        return ejectorList;
    }
}
