package cn.blatter.network.service;

import cn.blatter.network.simulator.simulate.Network;

/**
 * @author tanyao
 * @Date 2020/8/14 0:38
 */
public interface SimulateService {
	Network simulate(Integer id);
}
