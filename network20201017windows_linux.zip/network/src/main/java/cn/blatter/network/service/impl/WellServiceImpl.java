package cn.blatter.network.service.impl;

import cn.blatter.network.domain.*;
import cn.blatter.network.mapper.PipeMapper;
import cn.blatter.network.mapper.WellMapper;
import cn.blatter.network.service.WellService;
import cn.blatter.network.utils.XMLUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service("wellService")
public class WellServiceImpl implements WellService {

	@Autowired
	private WellMapper wellMapper;

	@Autowired
	private ElementServiceImpl elementService;

	@Autowired
	private ConnectionServiceImpl connectionService;

	@Autowired
	private ProjectsServiceImpl projectsService;

	@Autowired
	private PipeMapper pipeMapper;

	//private static String path1 = "src/main/resources";
	private String path1 = getPathRoot();

	public String getPathRoot() {
		String pathRoot = this.getClass().getResource("").getPath();
		//System.out.println(pathRoot);
		int index = pathRoot.indexOf("target/");
		if(pathRoot.charAt(0)=='f' && isWindows()) {
			pathRoot = pathRoot.substring(6, index);
		}
		else if(pathRoot.charAt(0)=='f' && isLinux()){
			pathRoot = pathRoot.substring(5, index);
		}
		else{
			pathRoot = pathRoot.substring(1, index);
		}
		pathRoot = pathRoot + "target/classes/";
		//System.out.println(pathRoot);
		return pathRoot;
	}

	public static boolean isLinux() {
		return System.getProperty("os.name").toLowerCase().contains("linux");
	}

	public static boolean isWindows() {
		return System.getProperty("os.name").toLowerCase().contains("windows");
	}

	@Override
	public List<Well> findAll(Integer id) {
		List<Well> wellList = wellMapper.findAll(id);
		return wellList;
	}

	@Override
	public void deleteWell(Integer id){
		try {
			Well well = findById(id);
			String path = path1 + projectsService.queryOne(well.getProjectId()).getModel();
			List<Element> elements = elementService.findAll();
			List<Connection> connections = connectionService.findAll();
			XMLUtil xmlUtil = new XMLUtil(elements, connections);
			List<Pipe> pipeList = xmlUtil.deleteNode(path, well);
			for (Pipe pipe : pipeList) {
				Pipe temp = pipeMapper.queryByModelId(pipe);
				pipeMapper.deleteById(temp.getId());
			}
			wellMapper.deleteWell(id);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void addWell(Well well){
		try {
			String path = path1 + projectsService.queryOne(well.getProjectId()).getModel();
			List<Element> elements = elementService.findAll();
			List<Connection> connections = connectionService.findAll();
			XMLUtil xmlUtil = new XMLUtil(elements, connections);
			xmlUtil.insertNode(path, well);
			wellMapper.addBase(well);
			wellMapper.addWell(well);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setWell(Well well){
		try {
			String path = path1 + projectsService.queryOne(well.getProjectId()).getModel();
			List<Element> elements = elementService.findAll();
			List<Connection> connections = connectionService.findAll();
			XMLUtil xmlUtil = new XMLUtil(elements, connections);
			xmlUtil.updateNode(path, well);
			wellMapper.setBase(well);
			wellMapper.setWell(well);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Well findById(Integer id){
		Well wellList = wellMapper.getBaseById(id);
		return wellList;
	}
}
