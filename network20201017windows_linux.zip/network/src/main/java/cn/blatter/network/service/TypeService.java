package cn.blatter.network.service;

import cn.blatter.network.domain.Type;

import java.util.List;

/**
 * @author tanyao
 * @Date 2020/8/5 16:47
 */
public interface TypeService {

	List<Type> findAll();
}
