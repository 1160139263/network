<template>
  <div id="project">
    <!-- <br />
    <el-row>
      <el-col :span="1" class="grid">
        <el-button
          type="success"
          @click="handleAddEdit"
          icon="el-icon-circle-plus-outline"
          size="mini"
          round
        >新增属性</el-button>
      </el-col>
    </el-row>
    <br /> -->
    <el-table
      :data="tableForm.slice((currentPage-1)*PageSize,currentPage*PageSize)"
      border
      ref="tableForm"
      style="width: 100%"
    >
      <el-table-column prop="id" label="元件属性id" width="150"></el-table-column>
      <el-table-column prop="elements[0].name" label="元件名称" width="150"></el-table-column>
      <el-table-column prop="attribute_name" label="元件属性名" width="150"></el-table-column>
      <el-table-column prop="attribute_value" label="元件属性值" width="150"></el-table-column>
      <el-table-column label="操作" width="200pt">
        <template slot-scope="scope">
          <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
          <!-- <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button> -->
        </template>
      </el-table-column>
    </el-table>
    <div class="tabListPage">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="PageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount"
      ></el-pagination>
    </div>

    <!-- 在el-dialog中进行嵌套el-form实现弹出表格的效果 -->
    <!-- <el-dialog title="新增属性" width="30%" :visible.sync="addFormVisible" @close="closeDialog">
      <el-form :rules="addEditRules" :model="addEditForm" ref="addEditForm">
        <el-form-item label="元件id" label-width="120px" prop="element_id">
          <el-input v-model="addEditForm.element_id" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="元件属性名" label-width="120px" prop="attribute_name">
          <el-input v-model="addEditForm.attribute_name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="元件属性值" label-width="120px" prop="attribute_value">
          <el-input v-model="addEditForm.attribute_value" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="addEdit">确 定</el-button>
      </div>
    </el-dialog> -->

    <!-- 在el-dialog中进行嵌套el-form实现弹出表格的效果 -->
    <el-dialog title="编辑" width="30%" :visible.sync="editFormVisible">
      <el-form :rules="editRules" :model="editForm" ref="editForm">
        <el-form-item label="属性名称" label-width="120px" prop="attribute_name">
          <el-input v-model="editForm.attribute_name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="属性值" label-width="120px" prop="attribute_value">
          <el-input v-model="editForm.attribute_value" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="update">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// eslint-disable-next-line camelcase
var id
// eslint-disable-next-line camelcase,no-unused-vars
var element_id
// eslint-disable-next-line camelcase,no-unused-vars
var attribute_name
// eslint-disable-next-line camelcase,no-unused-vars
var attribute_value
// eslint-disable-next-line camelcase,no-unused-vars
var elements_name

export default {
  name: 'attribute',
  inject: ['reload'],
  methods: {
    // 关闭弹框
    closeDialog () {
      this.addEditForm.element_id = ''
      this.addEditForm.attribute_name = ''
      this.addEditForm.attribute_value = ''
    },
    cancel () {
      this.reload()
      // 取消的时候直接设置对话框不可见即可
      this.editFormVisible = false
      this.addFormVisible = false
    },
    // 编辑
    handleEdit (row) {
      this.editForm = row
      id = row.id
      // eslint-disable-next-line camelcase
      element_id = row.element_id
      // id = row.id
      // eslint-disable-next-line camelcase
      elements_name = row.elements[0].name
      // eslint-disable-next-line camelcase
      attribute_name = row.attribute_name
      // eslint-disable-next-line camelcase
      attribute_value = row.attribute_value
      this.editFormVisible = true
    },
    // 删除
    // handleDelete (row) {
    //   var that = this
    //   this.$confirm('永久删除此条属性, 是否继续?', '提示', {
    //     confirmButtonText: '确定',
    //     cancelButtonText: '取消',
    //     type: 'warning'
    //   }).then(() => {
    //     // eslint-disable-next-line camelcase
    //     id = row.id
    //     that.$axios
    //       .post('/deleteAttribute', {
    //         id: id
    //       })
    //       .then((response) => {
    //         // eslint-disable-next-line eqeqeq
    //         if (response.status == 200) {
    //           that.cancel()
    //         }
    //       })
    //       .catch(function (error) {
    //         console.log(error)
    //       })
    //   })
    // },
    // boolean值格式化
    formatBoolean: function (row, column, cellValue) {
      let ret
      if (cellValue) {
        ret = '是'
      } else {
        ret = '否'
      }
      return ret
    },
    // addEdit () {
    //   this.$refs.addEditForm.validate((valid) => {
    //     if (valid) {
    //       var that = this
    //       // eslint-disable-next-line camelcase
    //       element_id = this.addEditForm.element_id
    //       this.$axios
    //         .post('/addAttribute', {
    //           element_id: element_id
    //         })
    //         .then((response) => {
    //           // eslint-disable-next-line eqeqeq
    //           if (response.status == 200) {
    //             that.$message('新增属性成功！')
    //             that.cancel()
    //           }
    //         })
    //         .catch(function (error) {
    //           console.log(error)
    //         })
    //     }
    //   })
    // },
    update () {
      this.$refs.editForm.validate((valid) => {
        if (valid) {
          var that = this
          // eslint-disable-next-line camelcase
          id = this.editForm.id
          // eslint-disable-next-line camelcase
          attribute_name = this.editForm.attribute_name
          // eslint-disable-next-line camelcase
          attribute_value = this.editForm.attribute_value
          // console.log(pressure_state)
          // console.log(load_state)
          this.$axios
            .post('/setAttribute', {
              id: id,
              attribute_name,
              attribute_value
            })
            .then((response) => {
              // eslint-disable-next-line eqeqeq
              if (response.status == 200) {
                that.cancel()
              }
            })
            .catch(function (error) {
              console.log(error)
            })
        }
      })
    },
    // 新建任务
    handleAddEdit () {
      this.addFormVisible = true
    },
    getAttribute () {
      this.$axios
        .get('/getAttribute')
        .then((response) => {
          // eslint-disable-next-line eqeqeq
          if (response.status == 200) {
            this.tableForm = response.data.data
            // console.log(response.data.data)
            this.totalCount = response.data.data.length
          }
        })
        .catch(function (error) {
          console.log(error)
        })
    },
    // 分页
    // 每页显示的条数
    handleSizeChange (val) {
      // 改变每页显示的条数
      this.PageSize = val
      // 注意：在改变每页显示的条数时，要将页码显示到第一页
      this.currentPage = 1
    },
    // 显示第几页
    handleCurrentChange (val) {
      // 改变默认的页数
      this.currentPage = val
    }
  },
  mounted () {
    this.getAttribute()
  },
  data () {
    return {
      tableForm: [],
      // 默认显示第几页
      currentPage: 1,
      // 总条数，根据接口获取数据长度(注意：这里不能为空)
      totalCount: 1,
      // 个数选择器（可修改）
      pageSizes: [10, 20, 30, 50],
      // 默认每页显示的条数（可修改）
      PageSize: 20,
      editFormVisible: false,
      addFormVisible: false,
      editForm: {
        id: 0,
        element_id: 0,
        attribute_name: '',
        attribute_value: 0,
        elements_name: ''
      },
      addEditForm: {
        id: 0,
        element_id: 0,
        attribute_name: '',
        attribute_value: 0,
        elements_name: ''
      },
      editRules: {
        attribute_name: [{ required: true, message: '请输入属性名', trigger: 'change' }],
        attribute_value: [{ required: true, message: '请输入属性值', trigger: 'change' }]
      },
      addEditRules: {
        element_id: [{ required: true, message: '请输入属性名', trigger: 'change' }],
        pressure: [{ required: true, message: '请输入属性值', trigger: 'change' }]
      }
    }
  }
}
</script>

<style scoped>
</style>
