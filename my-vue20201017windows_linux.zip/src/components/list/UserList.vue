<template>
  <div id="project">
    <br />
    <el-row>
      <el-col :span="1" class="grid">
        <el-button
          type="success"
          @click="handleAddEdit"
          icon="el-icon-circle-plus-outline"
          size="mini"
          round
        >新增用户</el-button>
      </el-col>
    </el-row>
    <br />
    <el-table
      :data="tableForm.slice((currentPage-1)*PageSize,currentPage*PageSize)"
      border
      ref="tableForm"
      style="width: 100%"
    >
      <el-table-column prop="uid" label="用户id" width="150"></el-table-column>
      <el-table-column prop="username" label="用户名" width="150"></el-table-column>
      <el-table-column prop="role" label="角色" width="150"></el-table-column>
      <el-table-column prop="name" label="备注名称" width="200"></el-table-column>
      <el-table-column label="操作" width="200pt">
        <template slot-scope="scope">
          <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="tabListPage">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="PageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount"
      ></el-pagination>
    </div>

    <!-- 在el-dialog中进行嵌套el-form实现弹出表格的效果 -->
    <el-dialog title="新增用户" width="30%" :visible.sync="addFormVisible" @close="closeDialog">
      <el-form :rules="addEditRules" :model="addEditForm" ref="addEditForm">
        <el-form-item label="用户名" label-width="80px" prop="username">
          <el-input v-model="addEditForm.username" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" label-width="80px" prop="password">
          <el-input v-model="addEditForm.password" auto-complete="off" type="password"></el-input>
        </el-form-item>
        <el-form-item label="角色" label-width="80px" prop="role">
          <el-input v-model="addEditForm.role" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="addEdit">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 在el-dialog中进行嵌套el-form实现弹出表格的效果 -->
    <el-dialog title="编辑" width="30%" :visible.sync="editFormVisible">
      <el-form :rules="editRules" :model="editForm" ref="editForm">
        <el-form-item label="用户名" label-width="80px" prop="username">
          <el-input v-model="editForm.username" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" label-width="80px" prop="password">
          <el-input v-model="editForm.password" auto-complete="off" type="password"></el-input>
        </el-form-item>
        <el-form-item label="角色" label-width="80px" prop="role">
          <el-input v-model="editForm.role" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="update">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import md5 from 'js-md5'
var uid
// eslint-disable-next-line camelcase,no-unused-vars
var username
var role
var password
export default {
  name: 'connection',
  inject: ['reload'],
  methods: {
    // 关闭弹框
    closeDialog () {
      this.addEditForm.username = ''
      this.addEditForm.password = ''
      this.addEditForm.uid = ''
      this.addEditForm.role = ''
    },
    cancel () {
      this.reload()
      // 取消的时候直接设置对话框不可见即可
      this.editFormVisible = false
      this.addFormVisible = false
    },
    // 编辑
    handleEdit (row) {
      // this.editForm = row
      this.editForm.uid = row.uid
      this.editForm.username = row.username
      this.editForm.role = row.role

      // eslint-disable-next-line camelcase
      username = row.username
      role = row.role
      password = row.password
      this.editFormVisible = true
    },
    // 删除
    handleDelete (row) {
      var that = this
      this.$confirm('永久删除此用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        uid = row.uid
        that.$axios
          .post('/users/deleteUser', {
            uid: uid
          })
          .then((response) => {
            // eslint-disable-next-line eqeqeq
            if (response.status == 200) {
              that.cancel()
            }
          })
          .catch(function (error) {
            console.log(error)
          })
      })
    },
    addEdit () {
      this.$refs.addEditForm.validate((valid) => {
        if (valid) {
          var that = this
          uid = this.addEditForm.uid
          // eslint-disable-next-line camelcase
          username = this.addEditForm.username
          role = this.addEditForm.role
          password = md5(this.addEditForm.password)
          this.$axios
            .post('/users/addUser', {
              uid: uid,
              username: username,
              password: password,
              role: role
            })
            .then((response) => {
              // eslint-disable-next-line eqeqeq
              if (response.status == 200) {
                that.$message('新增用户成功！')
                that.cancel()
              }
            })
            .catch(function (error) {
              console.log(error)
            })
        }
      })
    },
    update () {
      this.$refs.editForm.validate((valid) => {
        if (valid) {
          var that = this
          uid = this.editForm.uid
          // eslint-disable-next-line camelcase
          username = this.editForm.username
          role = this.editForm.role
          password = this.editForm.password
          // console.log(password)
          password = md5(password)
          // console.log(password)
          this.$axios
            .post('/users/setUser', {
              uid: uid,
              username: username,
              password: password,
              role: role
            })
            .then((response) => {
              // eslint-disable-next-line eqeqeq
              if (response.status == 200) {
                that.$message('编辑用户成功！')
                that.cancel()
              }
            })
            .catch(function (error) {
              console.log(error)
            })
        }
      })
    },
    // 新建任务
    handleAddEdit () {
      this.addFormVisible = true
    },
    getUser () {
      this.$axios
        .get('/users/getUser')
        .then((response) => {
          // eslint-disable-next-line eqeqeq
          if (response.status == 200) {
            for (let i = 0; i < response.data.data.length; i++) {
              // console.log(response.data.data[i])
              if (response.data.data[i].role === 0) {
                response.data.data[i].name = '管理员'
              } else if (response.data.data[i].role === 1) {
                response.data.data[i].name = '操作员'
              } else if (response.data.data[i].role === 2) {
                response.data.data[i].name = '游客'
              }
            }
            this.tableForm = response.data.data
            this.totalCount = response.data.data.length
          }
        })
        .catch(function (error) {
          console.log(error)
        })
    },
    // 分页
    // 每页显示的条数
    handleSizeChange (val) {
      // 改变每页显示的条数
      this.PageSize = val
      // 注意：在改变每页显示的条数时，要将页码显示到第一页
      this.currentPage = 1
    },
    // 显示第几页
    handleCurrentChange (val) {
      // 改变默认的页数
      this.currentPage = val
    }
  },
  mounted () {
    this.getUser()
  },
  data () {
    return {
      tableForm: [],
      // 默认显示第几页
      currentPage: 1,
      // 总条数，根据接口获取数据长度(注意：这里不能为空)
      totalCount: 1,
      // 个数选择器（可修改）
      pageSizes: [10, 20, 30, 50],
      // 默认每页显示的条数（可修改）
      PageSize: 10,
      editFormVisible: false,
      addFormVisible: false,
      editForm: {
        username: '',
        password: '',
        uid: '',
        role: ''
      },
      addEditForm: {
        username: '',
        password: '',
        uid: '',
        role: ''
      },
      editRules: {
        username: [{ required: true, message: '请输入用户名', trigger: 'change' }],
        password: [{ required: true, message: '请输入密码', trigger: 'change' }],
        uid: [{ required: true, message: '请输入uid', trigger: 'change' }],
        role: [{ required: true, message: '请输入角色', trigger: 'change' }]
      },
      addEditRules: {
        username: [{ required: true, message: '请输入用户名', trigger: 'change' },
          { min: 4, max: 12, message: '长度在 4 到 12 个字符', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'change' },
          { min: 6, max: 15, message: '长度在 6 到 15 个字符', trigger: 'blur' }],
        uid: [{ required: true, message: '请输入uid', trigger: 'change' }],
        role: [{ required: true, message: '请输入角色', trigger: 'change' }]
      }
    }
  }
}
</script>

<style scoped>
</style>
